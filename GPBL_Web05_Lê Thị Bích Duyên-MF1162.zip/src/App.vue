<template>
  <router-view />
  <div>
    

  </div>
</template>

<script>

export default {
  name: "App",
  components: {
  },
};
</script>

<style lang="css">
@import url("@/css/main.css");
</style>
